#ifndef _RTE_BRUECKENKRAN_TEMPLATE_V_U__PARAMETERS_H
#define _RTE_BRUECKENKRAN_TEMPLATE_V_U__PARAMETERS_H
#include "rtwtypes.h"
#include "SegmentInfo.hpp"

namespace slrealtime
{
  SegmentVector &getSegmentVector(void);
}                                      // slrealtime

#endif
