#include "rte_Brueckenkran_Template_V1u2_parameters.h"
#include "Brueckenkran_Template_V1u2.h"
#include "Brueckenkran_Template_V1u2_cal.h"

extern Brueckenkran_Template__cal_type Brueckenkran_Template__cal_impl;
namespace slrealtime
{
  /* Description of SEGMENTS */
  SegmentVector segmentInfo {
    { (void*)&Brueckenkran_Template__cal_impl, (void**)
      &Brueckenkran_Template_V1u2_cal, sizeof(Brueckenkran_Template__cal_type),
      2 }
  };

  SegmentVector &getSegmentVector(void)
  {
    return segmentInfo;
  }
}                                      // slrealtime
