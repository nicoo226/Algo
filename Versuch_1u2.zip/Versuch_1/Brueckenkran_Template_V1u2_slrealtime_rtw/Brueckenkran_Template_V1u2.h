/*
 * Brueckenkran_Template_V1u2.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Brueckenkran_Template_V1u2".
 *
 * Model version              : 10.287
 * Simulink Coder version : 9.9 (R2023a) 19-Nov-2022
 * C++ source code generated on : Tue May 27 14:45:08 2025
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Brueckenkran_Template_V1u2_h_
#define RTW_HEADER_Brueckenkran_Template_V1u2_h_
#include <logsrv.h>
#include <thread>
#include <chrono>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "verify/verifyIntrf.h"
#include "Clock.hpp"
#include "ModelInfo.hpp"
#include "StartCallbackAPI.h"
#include "sg_fpga_io30x_setup_util.h"
#include "sg_fpga_io31x_io32x_setup_util.h"
#include "sg_fpga_io33x_setup_util.h"
#include "sg_fpga_io39x_setup_util.h"
#include "sg_common.h"
#include "sg_printf.h"
#include "Brueckenkran_Template_V1u2_types.h"
#include <stddef.h>
#include <cstring>
#include "Brueckenkran_Template_V1u2_cal.h"

extern "C"
{

#include "rt_nonfinite.h"

}

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
#define rtmGetOdeF(rtm)                ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
#define rtmSetOdeF(rtm, val)           ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
#define rtmGetOdeY(rtm)                ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
#define rtmSetOdeY(rtm, val)           ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetSampleHitArray
#define rtmGetSampleHitArray(rtm)      ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmGetStepSize
#define rtmGetStepSize(rtm)            ((rtm)->Timing.stepSize)
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
#define rtmGet_TimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

#ifndef rtmGetTimeOfLastOutput
#define rtmGetTimeOfLastOutput(rtm)    ((rtm)->Timing.timeOfLastOutput)
#endif

/* Block signals (default storage) */
struct B_Brueckenkran_Template_V1u2_T {
  real_T PulseGenerator;               /* '<Root>/Pulse Generator' */
  real_T Saturation1;                  /* '<Root>/Saturation1' */
  real_T IO397AnalogInput_o1;          /* '<Root>/IO397 Analog Input' */
  real_T IO397AnalogInput_o2;          /* '<Root>/IO397 Analog Input' */
  real_T V2A;                          /* '<Root>/V2A' */
  real_T Bias;                         /* '<Root>/Bias' */
  real_T Sum1;                         /* '<Root>/Sum1' */
  real_T Saturation;                   /* '<Root>/Saturation' */
  real_T uGainPE;                      /* '<Root>/1//GainPE' */
  real_T Sum;                          /* '<Root>/Sum' */
  real_T logic2rad;                    /* '<Root>/logic2rad' */
  real_T Clock;                        /* '<Root>/Clock' */
  real_T PulseGenerator1;              /* '<Root>/Pulse Generator1' */
  real_T Uk1;                          /* '<S6>/Delay Input1' */
  real_T Uk1_e;                        /* '<S5>/Delay Input1' */
  real_T Clock_k;                      /* '<S1>/Clock' */
  real_T Integrator;                   /* '<S2>/Integrator' */
  real_T Sum1_e;                       /* '<S2>/Sum1' */
  real_T Gain1;                        /* '<S2>/Gain1' */
  real_T Gain2;                        /* '<S2>/Gain2' */
  real_T RecordingOn;                  /* '<S1>/Triggered_Recording_TimeSpan' */
  uint32_T OverloadOptionsCore;        /* '<S3>/Overload Options Core' */
  boolean_T FixPtRelationalOperator;   /* '<S6>/FixPt Relational Operator' */
  boolean_T FixPtRelationalOperator_n; /* '<S5>/FixPt Relational Operator' */
  boolean_T LogicalOperator;           /* '<S1>/Logical Operator' */
  boolean_T DataTypeConversion;        /* '<S1>/Data Type Conversion' */
};

/* Block states (default storage) for system '<Root>' */
struct DW_Brueckenkran_Template_V1u2_T {
  real_T DelayInput1_DSTATE;           /* '<S6>/Delay Input1' */
  real_T DelayInput1_DSTATE_m;         /* '<S5>/Delay Input1' */
  real_T halfPeriod;                   /* '<S1>/Triggered_Recording_TimeSpan' */
  real_T halfPeriodDetermined;         /* '<S1>/Triggered_Recording_TimeSpan' */
  real_T StartTime;                    /* '<S1>/Triggered_Recording_TimeSpan' */
  real_T RecordingStartet;             /* '<S1>/Triggered_Recording_TimeSpan' */
  real_T RecordingActivatedSetBack;    /* '<S1>/Triggered_Recording_TimeSpan' */
  void *IO397AnalogInput_PWORK[2];     /* '<Root>/IO397 Analog Input' */
  void *IO397AnalogOutput_PWORK[2];    /* '<Root>/IO397 Analog Output' */
  struct {
    void *LoggedData;
  } ShowData_PWORK;                    /* '<Root>/Show Data' */

  struct {
    void *LoggedData;
  } ShowData1_PWORK;                   /* '<Root>/Show Data1' */

  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<S1>/Scope' */

  struct {
    void *USERIO_P_IND;
    void *PROG_SPACE_P_IND;
    void *CONFIG_REGISTER_P_IND;
    void *CONDITIONING_MODULE_IO3xx_2x_P_IND;
    void *DEVICENAME_P_IND;
  } Setup_PWORK;                       /* '<Root>/Setup' */

  struct {
    void *AQHandles;
    void *SLRTSigHandles;
  } TAQSigLogging_InsertedFor_ia_at;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SLRTSigHandles;
  } TAQSigLogging_InsertedFor_ua_at;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SLRTSigHandles;
  } TAQSigLogging_InsertedFor_Ia_so;   /* synthesized block */

  struct {
    void *AQHandles;
    void *SLRTSigHandles;
  } TAQSigLogging_InsertedFor_Theta;   /* synthesized block */

  int32_T clockTickCounter;            /* '<Root>/Pulse Generator' */
  int32_T clockTickCounter_m;          /* '<Root>/Pulse Generator1' */
  int32_T sfEvent;                     /* '<S1>/Triggered_Recording_TimeSpan' */
  uint32_T OverloadOptionsCore_DWORK1; /* '<S3>/Overload Options Core' */
  int_T IO397AnalogOutput_IWORK;       /* '<Root>/IO397 Analog Output' */
  struct {
    int_T MODULEARCHITECTURE_I_IND;
  } Setup_IWORK;                       /* '<Root>/Setup' */

  int8_T EnabledSubsystem_SubsysRanBC; /* '<Root>/Enabled Subsystem' */
  int8_T DataloggingONOFF_SubsysRanBC; /* '<S1>/DataloggingONOFF' */
  uint8_T is_active_c2_Brueckenkran_Templ;/* '<S1>/Triggered_Recording_TimeSpan' */
  boolean_T OverloadOptionsCore_DWORK2;/* '<S3>/Overload Options Core' */
  boolean_T doneDoubleBufferReInit;    /* '<S1>/Triggered_Recording_TimeSpan' */
  boolean_T halfPeriod_not_empty;      /* '<S1>/Triggered_Recording_TimeSpan' */
  boolean_T halfPeriodDetermined_not_empty;/* '<S1>/Triggered_Recording_TimeSpan' */
  boolean_T StartTime_not_empty;       /* '<S1>/Triggered_Recording_TimeSpan' */
  boolean_T RecordingStartet_not_empty;/* '<S1>/Triggered_Recording_TimeSpan' */
  boolean_T RecordingActivatedSetBack_not_e;/* '<S1>/Triggered_Recording_TimeSpan' */
  boolean_T EnabledSubsystem_MODE;     /* '<Root>/Enabled Subsystem' */
};

/* Continuous states (default storage) */
struct X_Brueckenkran_Template_V1u2_T {
  real_T Integrator_CSTATE;            /* '<S2>/Integrator' */
};

/* State derivatives (default storage) */
struct XDot_Brueckenkran_Template_V1u2_T {
  real_T Integrator_CSTATE;            /* '<S2>/Integrator' */
};

/* State disabled  */
struct XDis_Brueckenkran_Template_V1u2_T {
  boolean_T Integrator_CSTATE;         /* '<S2>/Integrator' */
};

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
struct ODE3_IntgData {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
};

#endif

/* Real-time Model Data Structure */
struct tag_RTM_Brueckenkran_Template_V1u2_T {
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * NonInlinedSFcns:
   * The following substructure contains information regarding
   * non-inlined s-functions used in the model.
   */
  struct {
    RTWSfcnInfo sfcnInfo;
    time_T *taskTimePtrs[2];
    SimStruct childSFunctions[3];
    SimStruct *childSFunctionPtrs[3];
    struct _ssBlkInfo2 blkInfo2[3];
    struct _ssSFcnModelMethods2 methods2[3];
    struct _ssSFcnModelMethods3 methods3[3];
    struct _ssSFcnModelMethods4 methods4[3];
    struct _ssStatesInfo2 statesInfo2[3];
    ssPeriodicStatesInfo periodicStatesInfo[3];
    struct _ssPortInfo2 inputOutputPortInfo2[3];
    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[11];
      mxArray *params[11];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn0;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[8];
      mxArray *params[8];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn1;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
    } Sfcn2;
  } NonInlinedSFcns;

  X_Brueckenkran_Template_V1u2_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_Brueckenkran_Template_V1u2_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[1];
  real_T odeF[3][1];
  ODE3_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T options;
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[2];
    time_T offsetTimesArray[2];
    int_T sampleTimeTaskIDArray[2];
    int_T sampleHitArray[2];
    int_T perTaskSampleHitsArray[4];
    time_T tArray[2];
  } Timing;
};

/* Block signals (default storage) */
#ifdef __cplusplus

extern "C"
{

#endif

  extern struct B_Brueckenkran_Template_V1u2_T Brueckenkran_Template_V1u2_B;

#ifdef __cplusplus

}

#endif

/* Continuous states (default storage) */
extern X_Brueckenkran_Template_V1u2_T Brueckenkran_Template_V1u2_X;

/* Block states (default storage) */
extern struct DW_Brueckenkran_Template_V1u2_T Brueckenkran_Template_V1u2_DW;

#ifdef __cplusplus

extern "C"
{

#endif

  /* Model entry point functions */
  extern void Brueckenkran_Template_V1u2_initialize(void);
  extern void Brueckenkran_Template_V1u2_step(void);
  extern void Brueckenkran_Template_V1u2_terminate(void);

#ifdef __cplusplus

}

#endif

/* Real-time Model object */
#ifdef __cplusplus

extern "C"
{

#endif

  extern RT_MODEL_Brueckenkran_Template_V1u2_T *const
    Brueckenkran_Template_V1u2_M;

#ifdef __cplusplus

}

#endif

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Brueckenkran_Template_V1u2'
 * '<S1>'   : 'Brueckenkran_Template_V1u2/DataLogging'
 * '<S2>'   : 'Brueckenkran_Template_V1u2/Enabled Subsystem'
 * '<S3>'   : 'Brueckenkran_Template_V1u2/Overload Options'
 * '<S4>'   : 'Brueckenkran_Template_V1u2/DataLogging/DataloggingONOFF'
 * '<S5>'   : 'Brueckenkran_Template_V1u2/DataLogging/Detect Decrease'
 * '<S6>'   : 'Brueckenkran_Template_V1u2/DataLogging/Detect Increase'
 * '<S7>'   : 'Brueckenkran_Template_V1u2/DataLogging/Triggered_Recording_TimeSpan'
 * '<S8>'   : 'Brueckenkran_Template_V1u2/DataLogging/DataloggingONOFF/File Log1'
 * '<S9>'   : 'Brueckenkran_Template_V1u2/DataLogging/DataloggingONOFF/File Log2'
 * '<S10>'  : 'Brueckenkran_Template_V1u2/DataLogging/DataloggingONOFF/File Log3'
 * '<S11>'  : 'Brueckenkran_Template_V1u2/DataLogging/DataloggingONOFF/File Log4'
 */
#endif                            /* RTW_HEADER_Brueckenkran_Template_V1u2_h_ */
