/*
 * Brueckenkran_Template_V1u2.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Brueckenkran_Template_V1u2".
 *
 * Model version              : 10.290
 * Simulink Coder version : 9.9 (R2023a) 19-Nov-2022
 * C++ source code generated on : Tue May 27 15:50:34 2025
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Brueckenkran_Template_V1u2.h"
#include "rtwtypes.h"
#include "Brueckenkran_Template_V1u2_cal.h"
#include "Brueckenkran_Template_V1u2_private.h"
#include <cstring>

extern "C"
{

#include "rt_nonfinite.h"

}

/* Named constants for MATLAB Function: '<S1>/Triggered_Recording_TimeSpan' */
const int32_T Brueckenkran_Templat_CALL_EVENT = -1;

/* Block signals (default storage) */
B_Brueckenkran_Template_V1u2_T Brueckenkran_Template_V1u2_B;

/* Continuous states */
X_Brueckenkran_Template_V1u2_T Brueckenkran_Template_V1u2_X;

/* Block states (default storage) */
DW_Brueckenkran_Template_V1u2_T Brueckenkran_Template_V1u2_DW;

/* Real-time model */
RT_MODEL_Brueckenkran_Template_V1u2_T Brueckenkran_Template_V1u2_M_ =
  RT_MODEL_Brueckenkran_Template_V1u2_T();
RT_MODEL_Brueckenkran_Template_V1u2_T *const Brueckenkran_Template_V1u2_M =
  &Brueckenkran_Template_V1u2_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = static_cast<ODE3_IntgData *>(rtsiGetSolverData(si));
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 1;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) std::memcpy(y, x,
                     static_cast<uint_T>(nXc)*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  Brueckenkran_Template_V1u2_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  Brueckenkran_Template_V1u2_step();
  Brueckenkran_Template_V1u2_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  Brueckenkran_Template_V1u2_step();
  Brueckenkran_Template_V1u2_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void Brueckenkran_Template_V1u2_step(void)
{
  real_T u0;
  real_T u1;
  real_T u2;
  if (rtmIsMajorTimeStep(Brueckenkran_Template_V1u2_M)) {
    /* set solver stop time */
    if (!(Brueckenkran_Template_V1u2_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&Brueckenkran_Template_V1u2_M->solverInfo,
                            ((Brueckenkran_Template_V1u2_M->Timing.clockTickH0 +
        1) * Brueckenkran_Template_V1u2_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&Brueckenkran_Template_V1u2_M->solverInfo,
                            ((Brueckenkran_Template_V1u2_M->Timing.clockTick0 +
        1) * Brueckenkran_Template_V1u2_M->Timing.stepSize0 +
        Brueckenkran_Template_V1u2_M->Timing.clockTickH0 *
        Brueckenkran_Template_V1u2_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(Brueckenkran_Template_V1u2_M)) {
    Brueckenkran_Template_V1u2_M->Timing.t[0] = rtsiGetT
      (&Brueckenkran_Template_V1u2_M->solverInfo);
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(Brueckenkran_Template_V1u2_DW.DataloggingONOFF_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(Brueckenkran_Template_V1u2_DW.EnabledSubsystem_SubsysRanBC);
  if (rtmIsMajorTimeStep(Brueckenkran_Template_V1u2_M)) {
    /* DiscretePulseGenerator: '<Root>/Pulse Generator' */
    Brueckenkran_Template_V1u2_B.PulseGenerator =
      (Brueckenkran_Template_V1u2_DW.clockTickCounter <
       Brueckenkran_Template_V1u2_cal->PulseGenerator_Duty) &&
      (Brueckenkran_Template_V1u2_DW.clockTickCounter >= 0) ?
      Brueckenkran_Template_V1u2_cal->PulseGenerator_Amp : 0.0;

    /* DiscretePulseGenerator: '<Root>/Pulse Generator' */
    if (Brueckenkran_Template_V1u2_DW.clockTickCounter >=
        Brueckenkran_Template_V1u2_cal->PulseGenerator_Period - 1.0) {
      Brueckenkran_Template_V1u2_DW.clockTickCounter = 0;
    } else {
      Brueckenkran_Template_V1u2_DW.clockTickCounter++;
    }

    /* Saturate: '<Root>/Saturation1' */
    u0 = Brueckenkran_Template_V1u2_B.PulseGenerator;
    u1 = Brueckenkran_Template_V1u2_cal->Saturation1_LowerSat;
    u2 = Brueckenkran_Template_V1u2_cal->Saturation1_UpperSat;
    if (u0 > u2) {
      /* Saturate: '<Root>/Saturation1' */
      Brueckenkran_Template_V1u2_B.Saturation1 = u2;
    } else if (u0 < u1) {
      /* Saturate: '<Root>/Saturation1' */
      Brueckenkran_Template_V1u2_B.Saturation1 = u1;
    } else {
      /* Saturate: '<Root>/Saturation1' */
      Brueckenkran_Template_V1u2_B.Saturation1 = u0;
    }

    /* End of Saturate: '<Root>/Saturation1' */

    /* S-Function (sg_fpga_IO397_ad): '<Root>/IO397 Analog Input' */

    /* Level2 S-Function Block: '<Root>/IO397 Analog Input' (sg_fpga_IO397_ad) */
    {
      SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[0];
      sfcnOutputs(rts,0);
    }

    /* Gain: '<Root>/V2A' */
    Brueckenkran_Template_V1u2_B.V2A = Brueckenkran_Template_V1u2_cal->V2A_Gain *
      Brueckenkran_Template_V1u2_B.IO397AnalogInput_o1;

    /* Bias: '<Root>/Bias' */
    Brueckenkran_Template_V1u2_B.Bias = Brueckenkran_Template_V1u2_B.V2A +
      Brueckenkran_Template_V1u2_cal->Bias_Bias;

    /* Sum: '<Root>/Sum1' */
    Brueckenkran_Template_V1u2_B.Sum1 = Brueckenkran_Template_V1u2_B.Saturation1
      - Brueckenkran_Template_V1u2_B.Bias;

    /* Outputs for Enabled SubSystem: '<Root>/Enabled Subsystem' incorporates:
     *  EnablePort: '<S2>/Enable'
     */
    if (rtsiIsModeUpdateTimeStep(&Brueckenkran_Template_V1u2_M->solverInfo)) {
      /* Constant: '<Root>/Constant' */
      Brueckenkran_Template_V1u2_DW.EnabledSubsystem_MODE =
        (Brueckenkran_Template_V1u2_cal->Constant_Value > 0.0);
    }

    /* End of Outputs for SubSystem: '<Root>/Enabled Subsystem' */
  }

  /* Outputs for Enabled SubSystem: '<Root>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S2>/Enable'
   */
  if (Brueckenkran_Template_V1u2_DW.EnabledSubsystem_MODE) {
    /* Integrator: '<S2>/Integrator' */
    Brueckenkran_Template_V1u2_B.Integrator =
      Brueckenkran_Template_V1u2_X.Integrator_CSTATE;

    /* Sum: '<S2>/Sum1' */
    Brueckenkran_Template_V1u2_B.Sum1_e =
      Brueckenkran_Template_V1u2_B.Integrator +
      Brueckenkran_Template_V1u2_B.Sum1;

    /* Gain: '<S2>/Gain1' */
    Brueckenkran_Template_V1u2_B.Gain1 =
      Brueckenkran_Template_V1u2_cal->Gain1_Gain *
      Brueckenkran_Template_V1u2_B.Sum1_e;
    if (rtmIsMajorTimeStep(Brueckenkran_Template_V1u2_M)) {
      /* Gain: '<S2>/Gain2' */
      Brueckenkran_Template_V1u2_B.Gain2 =
        Brueckenkran_Template_V1u2_cal->Gain2_Gain *
        Brueckenkran_Template_V1u2_B.Sum1;
    }

    if (rtsiIsModeUpdateTimeStep(&Brueckenkran_Template_V1u2_M->solverInfo)) {
      srUpdateBC(Brueckenkran_Template_V1u2_DW.EnabledSubsystem_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<Root>/Enabled Subsystem' */

  /* Saturate: '<Root>/Saturation' */
  u0 = Brueckenkran_Template_V1u2_B.Gain1;
  u1 = Brueckenkran_Template_V1u2_cal->Saturation_LowerSat;
  u2 = Brueckenkran_Template_V1u2_cal->Saturation_UpperSat;
  if (u0 > u2) {
    /* Saturate: '<Root>/Saturation' */
    Brueckenkran_Template_V1u2_B.Saturation = u2;
  } else if (u0 < u1) {
    /* Saturate: '<Root>/Saturation' */
    Brueckenkran_Template_V1u2_B.Saturation = u1;
  } else {
    /* Saturate: '<Root>/Saturation' */
    Brueckenkran_Template_V1u2_B.Saturation = u0;
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* Gain: '<Root>/1//GainPE' */
  Brueckenkran_Template_V1u2_B.uGainPE =
    Brueckenkran_Template_V1u2_cal->uGainPE_Gain *
    Brueckenkran_Template_V1u2_B.Saturation;
  if (rtmIsMajorTimeStep(Brueckenkran_Template_V1u2_M)) {
    /* S-Function (sg_fpga_IO397_da): '<Root>/IO397 Analog Output' */

    /* Level2 S-Function Block: '<Root>/IO397 Analog Output' (sg_fpga_IO397_da) */
    {
      SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[1];
      sfcnOutputs(rts,0);
    }

    /* Sum: '<Root>/Sum' incorporates:
     *  Constant: '<Root>/Offset_Poti'
     */
    Brueckenkran_Template_V1u2_B.Sum =
      Brueckenkran_Template_V1u2_B.IO397AnalogInput_o2 -
      Brueckenkran_Template_V1u2_cal->Offset_Poti_Value;

    /* Gain: '<Root>/logic2rad' */
    Brueckenkran_Template_V1u2_B.logic2rad =
      Brueckenkran_Template_V1u2_cal->logic2rad_Gain *
      Brueckenkran_Template_V1u2_B.Sum;
  }

  /* S-Function (overloadoptions): '<S3>/Overload Options Core' */
  if (Brueckenkran_Template_V1u2_DW.OverloadOptionsCore_DWORK2 == true ) {
    Brueckenkran_Template_V1u2_DW.OverloadOptionsCore_DWORK1 = slrealtime::
      getThreadTID(std::this_thread::get_id());
    Brueckenkran_Template_V1u2_DW.OverloadOptionsCore_DWORK2 = false;
  }

  slrealtime::getModelInstanceModelInfo()
    .tasks_[Brueckenkran_Template_V1u2_DW.OverloadOptionsCore_DWORK1].
    overload_.startupDur_ =
    Brueckenkran_Template_V1u2_cal->OverloadOptions_startupDur;
  slrealtime::getModelInstanceModelInfo()
    .tasks_[Brueckenkran_Template_V1u2_DW.OverloadOptionsCore_DWORK1].
    overload_.max_ = Brueckenkran_Template_V1u2_cal->OverloadOptions_maxOverload;
  Brueckenkran_Template_V1u2_B.OverloadOptionsCore = slrealtime::
    getModelInstanceModelInfo()
    .tasks_[Brueckenkran_Template_V1u2_DW.OverloadOptionsCore_DWORK1].
    overload_.count_;

  /* Clock: '<Root>/Clock' */
  Brueckenkran_Template_V1u2_B.Clock = Brueckenkran_Template_V1u2_M->Timing.t[0];

  /* Clock: '<S1>/Clock' */
  Brueckenkran_Template_V1u2_B.Clock_k = Brueckenkran_Template_V1u2_M->Timing.t
    [0];
  if (rtmIsMajorTimeStep(Brueckenkran_Template_V1u2_M)) {
    /* DiscretePulseGenerator: '<Root>/Pulse Generator1' */
    Brueckenkran_Template_V1u2_B.PulseGenerator1 =
      (Brueckenkran_Template_V1u2_DW.clockTickCounter_m <
       Brueckenkran_Template_V1u2_cal->PulseGenerator1_Duty) &&
      (Brueckenkran_Template_V1u2_DW.clockTickCounter_m >= 0) ?
      Brueckenkran_Template_V1u2_cal->PulseGenerator1_Amp : 0.0;

    /* DiscretePulseGenerator: '<Root>/Pulse Generator1' */
    if (Brueckenkran_Template_V1u2_DW.clockTickCounter_m >=
        Brueckenkran_Template_V1u2_cal->PulseGenerator1_Period - 1.0) {
      Brueckenkran_Template_V1u2_DW.clockTickCounter_m = 0;
    } else {
      Brueckenkran_Template_V1u2_DW.clockTickCounter_m++;
    }

    /* UnitDelay: '<S6>/Delay Input1' */
    Brueckenkran_Template_V1u2_B.Uk1 =
      Brueckenkran_Template_V1u2_DW.DelayInput1_DSTATE;

    /* RelationalOperator: '<S6>/FixPt Relational Operator' */
    Brueckenkran_Template_V1u2_B.FixPtRelationalOperator =
      (Brueckenkran_Template_V1u2_B.PulseGenerator1 >
       Brueckenkran_Template_V1u2_B.Uk1);

    /* UnitDelay: '<S5>/Delay Input1' */
    Brueckenkran_Template_V1u2_B.Uk1_e =
      Brueckenkran_Template_V1u2_DW.DelayInput1_DSTATE_m;

    /* RelationalOperator: '<S5>/FixPt Relational Operator' */
    Brueckenkran_Template_V1u2_B.FixPtRelationalOperator_n =
      (Brueckenkran_Template_V1u2_B.PulseGenerator1 <
       Brueckenkran_Template_V1u2_B.Uk1_e);

    /* MATLAB Function: '<S1>/Triggered_Recording_TimeSpan' incorporates:
     *  Constant: '<Root>/Delay'
     *  Constant: '<Root>/Record_Timespan_Activated'
     *  Constant: '<Root>/TimeSpan'
     */
    Brueckenkran_Template_V1u2_DW.sfEvent = Brueckenkran_Templat_CALL_EVENT;

    /* MATLAB Function 'DataLogging/Triggered_Recording_TimeSpan': '<S7>:1' */
    if (Brueckenkran_Template_V1u2_B.FixPtRelationalOperator &&
        (Brueckenkran_Template_V1u2_DW.halfPeriodDetermined == 0.0)) {
      /* '<S7>:1:19' */
      /* '<S7>:1:20' */
      Brueckenkran_Template_V1u2_DW.halfPeriod =
        Brueckenkran_Template_V1u2_B.Clock_k;

      /* '<S7>:1:21' */
      Brueckenkran_Template_V1u2_DW.halfPeriodDetermined = 1.0;
    }

    if (Brueckenkran_Template_V1u2_B.FixPtRelationalOperator_n &&
        (Brueckenkran_Template_V1u2_DW.halfPeriodDetermined == 1.0)) {
      /* '<S7>:1:24' */
      /* '<S7>:1:25' */
      Brueckenkran_Template_V1u2_DW.halfPeriod =
        Brueckenkran_Template_V1u2_B.Clock_k -
        Brueckenkran_Template_V1u2_DW.halfPeriod;

      /* '<S7>:1:26' */
      Brueckenkran_Template_V1u2_DW.halfPeriodDetermined = 2.0;
    }

    if ((Brueckenkran_Template_V1u2_DW.halfPeriodDetermined == 2.0) &&
        (Brueckenkran_Template_V1u2_cal->Record_Timespan_Activated_Value == 1.0)
        && (Brueckenkran_Template_V1u2_DW.RecordingActivatedSetBack != 0.0) &&
        Brueckenkran_Template_V1u2_B.FixPtRelationalOperator &&
        (Brueckenkran_Template_V1u2_DW.RecordingStartet == 0.0)) {
      /* '<S7>:1:29' */
      /* '<S7>:1:30' */
      Brueckenkran_Template_V1u2_DW.StartTime =
        Brueckenkran_Template_V1u2_B.Clock_k;

      /* '<S7>:1:31' */
      Brueckenkran_Template_V1u2_DW.RecordingStartet = 1.0;

      /* '<S7>:1:32' */
      Brueckenkran_Template_V1u2_DW.RecordingActivatedSetBack = 0.0;
    }

    u0 = Brueckenkran_Template_V1u2_B.Clock_k -
      Brueckenkran_Template_V1u2_DW.StartTime;
    u1 = 2.0 * Brueckenkran_Template_V1u2_DW.halfPeriod +
      Brueckenkran_Template_V1u2_cal->TimeSpan_Value;
    if ((u0 >= 2.0 * Brueckenkran_Template_V1u2_DW.halfPeriod -
         Brueckenkran_Template_V1u2_cal->Delay_Value) && (u0 <= u1) &&
        (Brueckenkran_Template_V1u2_DW.RecordingStartet != 0.0)) {
      /* '<S7>:1:35' */
      /* '<S7>:1:36' */
      Brueckenkran_Template_V1u2_B.RecordingOn = 1.0;
    } else if ((u0 > u1) && (Brueckenkran_Template_V1u2_DW.RecordingStartet ==
                1.0)) {
      /* '<S7>:1:37' */
      /* '<S7>:1:38' */
      Brueckenkran_Template_V1u2_DW.RecordingStartet = 0.0;

      /* '<S7>:1:39' */
      Brueckenkran_Template_V1u2_B.RecordingOn = 0.0;
    } else {
      /* '<S7>:1:41' */
      Brueckenkran_Template_V1u2_B.RecordingOn = 0.0;
    }

    if (Brueckenkran_Template_V1u2_cal->Record_Timespan_Activated_Value == 0.0)
    {
      /* '<S7>:1:44' */
      /* '<S7>:1:45' */
      Brueckenkran_Template_V1u2_DW.RecordingActivatedSetBack = 1.0;
    }

    /* End of MATLAB Function: '<S1>/Triggered_Recording_TimeSpan' */

    /* Logic: '<S1>/Logical Operator' incorporates:
     *  Constant: '<Root>/Record_Immediately'
     */
    Brueckenkran_Template_V1u2_B.LogicalOperator =
      ((Brueckenkran_Template_V1u2_cal->Record_Immediately_Value != 0.0) ||
       (Brueckenkran_Template_V1u2_B.RecordingOn != 0.0));

    /* DataTypeConversion: '<S1>/Data Type Conversion' */
    Brueckenkran_Template_V1u2_B.DataTypeConversion =
      Brueckenkran_Template_V1u2_B.LogicalOperator;

    /* S-Function (slrealtimeenablelogging): '<S1>/Enable File Log' */

    /* Level2 S-Function Block: '<S1>/Enable File Log' (slrealtimeenablelogging) */
    {
      SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[2];
      sfcnOutputs(rts,0);
    }

    /* Outputs for Enabled SubSystem: '<S1>/DataloggingONOFF' incorporates:
     *  EnablePort: '<S4>/Enable'
     */
    /* Constant: '<S1>/Constant1' */
    if (Brueckenkran_Template_V1u2_cal->Constant1_Value > 0.0) {
      /* ToAsyncQueueBlock generated from: '<S11>/ia' */
      slrtLogSignal
        (Brueckenkran_Template_V1u2_DW.TAQSigLogging_InsertedFor_ia_at.SLRTSigHandles,
         Brueckenkran_Template_V1u2_M->Timing.t[1]);

      /* ToAsyncQueueBlock generated from: '<S10>/ua' */
      slrtLogSignal
        (Brueckenkran_Template_V1u2_DW.TAQSigLogging_InsertedFor_ua_at.SLRTSigHandles,
         Brueckenkran_Template_V1u2_M->Timing.t[1]);

      /* ToAsyncQueueBlock generated from: '<S8>/Ia_soll' */
      slrtLogSignal
        (Brueckenkran_Template_V1u2_DW.TAQSigLogging_InsertedFor_Ia_so.SLRTSigHandles,
         Brueckenkran_Template_V1u2_M->Timing.t[1]);

      /* ToAsyncQueueBlock generated from: '<S9>/Theta' */
      slrtLogSignal
        (Brueckenkran_Template_V1u2_DW.TAQSigLogging_InsertedFor_Theta.SLRTSigHandles,
         Brueckenkran_Template_V1u2_M->Timing.t[1]);
      if (rtsiIsModeUpdateTimeStep(&Brueckenkran_Template_V1u2_M->solverInfo)) {
        srUpdateBC(Brueckenkran_Template_V1u2_DW.DataloggingONOFF_SubsysRanBC);
      }
    }

    /* End of Constant: '<S1>/Constant1' */
    /* End of Outputs for SubSystem: '<S1>/DataloggingONOFF' */
  }

  if (rtmIsMajorTimeStep(Brueckenkran_Template_V1u2_M)) {
    if (rtmIsMajorTimeStep(Brueckenkran_Template_V1u2_M)) {
      /* Update for UnitDelay: '<S6>/Delay Input1' */
      Brueckenkran_Template_V1u2_DW.DelayInput1_DSTATE =
        Brueckenkran_Template_V1u2_B.PulseGenerator1;

      /* Update for UnitDelay: '<S5>/Delay Input1' */
      Brueckenkran_Template_V1u2_DW.DelayInput1_DSTATE_m =
        Brueckenkran_Template_V1u2_B.PulseGenerator1;
    }
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(Brueckenkran_Template_V1u2_M)) {
    rt_ertODEUpdateContinuousStates(&Brueckenkran_Template_V1u2_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++Brueckenkran_Template_V1u2_M->Timing.clockTick0)) {
      ++Brueckenkran_Template_V1u2_M->Timing.clockTickH0;
    }

    Brueckenkran_Template_V1u2_M->Timing.t[0] = rtsiGetSolverStopTime
      (&Brueckenkran_Template_V1u2_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.0001s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The absolute time is the multiplication of "clockTick1"
       * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
       * overflow during the application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      if (!(++Brueckenkran_Template_V1u2_M->Timing.clockTick1)) {
        ++Brueckenkran_Template_V1u2_M->Timing.clockTickH1;
      }

      Brueckenkran_Template_V1u2_M->Timing.t[1] =
        Brueckenkran_Template_V1u2_M->Timing.clockTick1 *
        Brueckenkran_Template_V1u2_M->Timing.stepSize1 +
        Brueckenkran_Template_V1u2_M->Timing.clockTickH1 *
        Brueckenkran_Template_V1u2_M->Timing.stepSize1 * 4294967296.0;
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void Brueckenkran_Template_V1u2_derivatives(void)
{
  XDot_Brueckenkran_Template_V1u2_T *_rtXdot;
  _rtXdot = ((XDot_Brueckenkran_Template_V1u2_T *)
             Brueckenkran_Template_V1u2_M->derivs);

  /* Derivatives for Enabled SubSystem: '<Root>/Enabled Subsystem' */
  if (Brueckenkran_Template_V1u2_DW.EnabledSubsystem_MODE) {
    /* Derivatives for Integrator: '<S2>/Integrator' */
    _rtXdot->Integrator_CSTATE = Brueckenkran_Template_V1u2_B.Gain2;
  } else {
    ((XDot_Brueckenkran_Template_V1u2_T *) Brueckenkran_Template_V1u2_M->derivs
      )->Integrator_CSTATE = 0.0;
  }

  /* End of Derivatives for SubSystem: '<Root>/Enabled Subsystem' */
}

/* Model initialize function */
void Brueckenkran_Template_V1u2_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Brueckenkran_Template_V1u2_M->solverInfo,
                          &Brueckenkran_Template_V1u2_M->Timing.simTimeStep);
    rtsiSetTPtr(&Brueckenkran_Template_V1u2_M->solverInfo, &rtmGetTPtr
                (Brueckenkran_Template_V1u2_M));
    rtsiSetStepSizePtr(&Brueckenkran_Template_V1u2_M->solverInfo,
                       &Brueckenkran_Template_V1u2_M->Timing.stepSize0);
    rtsiSetdXPtr(&Brueckenkran_Template_V1u2_M->solverInfo,
                 &Brueckenkran_Template_V1u2_M->derivs);
    rtsiSetContStatesPtr(&Brueckenkran_Template_V1u2_M->solverInfo, (real_T **)
                         &Brueckenkran_Template_V1u2_M->contStates);
    rtsiSetNumContStatesPtr(&Brueckenkran_Template_V1u2_M->solverInfo,
      &Brueckenkran_Template_V1u2_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&Brueckenkran_Template_V1u2_M->solverInfo,
      &Brueckenkran_Template_V1u2_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&Brueckenkran_Template_V1u2_M->solverInfo,
      &Brueckenkran_Template_V1u2_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&Brueckenkran_Template_V1u2_M->solverInfo,
      &Brueckenkran_Template_V1u2_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&Brueckenkran_Template_V1u2_M->solverInfo,
                          (&rtmGetErrorStatus(Brueckenkran_Template_V1u2_M)));
    rtsiSetRTModelPtr(&Brueckenkran_Template_V1u2_M->solverInfo,
                      Brueckenkran_Template_V1u2_M);
  }

  rtsiSetSimTimeStep(&Brueckenkran_Template_V1u2_M->solverInfo, MAJOR_TIME_STEP);
  Brueckenkran_Template_V1u2_M->intgData.y = Brueckenkran_Template_V1u2_M->odeY;
  Brueckenkran_Template_V1u2_M->intgData.f[0] =
    Brueckenkran_Template_V1u2_M->odeF[0];
  Brueckenkran_Template_V1u2_M->intgData.f[1] =
    Brueckenkran_Template_V1u2_M->odeF[1];
  Brueckenkran_Template_V1u2_M->intgData.f[2] =
    Brueckenkran_Template_V1u2_M->odeF[2];
  Brueckenkran_Template_V1u2_M->contStates = ((X_Brueckenkran_Template_V1u2_T *)
    &Brueckenkran_Template_V1u2_X);
  rtsiSetSolverData(&Brueckenkran_Template_V1u2_M->solverInfo, static_cast<void *>
                    (&Brueckenkran_Template_V1u2_M->intgData));
  rtsiSetIsMinorTimeStepWithModeChange(&Brueckenkran_Template_V1u2_M->solverInfo,
    false);
  rtsiSetSolverName(&Brueckenkran_Template_V1u2_M->solverInfo,"ode3");
  Brueckenkran_Template_V1u2_M->solverInfoPtr =
    (&Brueckenkran_Template_V1u2_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = Brueckenkran_Template_V1u2_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;

    /* polyspace +2 MISRA2012:D4.1 [Justified:Low] "Brueckenkran_Template_V1u2_M points to
       static memory which is guaranteed to be non-NULL" */
    Brueckenkran_Template_V1u2_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    Brueckenkran_Template_V1u2_M->Timing.sampleTimes =
      (&Brueckenkran_Template_V1u2_M->Timing.sampleTimesArray[0]);
    Brueckenkran_Template_V1u2_M->Timing.offsetTimes =
      (&Brueckenkran_Template_V1u2_M->Timing.offsetTimesArray[0]);

    /* task periods */
    Brueckenkran_Template_V1u2_M->Timing.sampleTimes[0] = (0.0);
    Brueckenkran_Template_V1u2_M->Timing.sampleTimes[1] = (0.0001);

    /* task offsets */
    Brueckenkran_Template_V1u2_M->Timing.offsetTimes[0] = (0.0);
    Brueckenkran_Template_V1u2_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(Brueckenkran_Template_V1u2_M,
             &Brueckenkran_Template_V1u2_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = Brueckenkran_Template_V1u2_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    Brueckenkran_Template_V1u2_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(Brueckenkran_Template_V1u2_M, -1);
  Brueckenkran_Template_V1u2_M->Timing.stepSize0 = 0.0001;
  Brueckenkran_Template_V1u2_M->Timing.stepSize1 = 0.0001;
  Brueckenkran_Template_V1u2_M->solverInfoPtr =
    (&Brueckenkran_Template_V1u2_M->solverInfo);
  Brueckenkran_Template_V1u2_M->Timing.stepSize = (0.0001);
  rtsiSetFixedStepSize(&Brueckenkran_Template_V1u2_M->solverInfo, 0.0001);
  rtsiSetSolverMode(&Brueckenkran_Template_V1u2_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  (void) std::memset((static_cast<void *>(&Brueckenkran_Template_V1u2_B)), 0,
                     sizeof(B_Brueckenkran_Template_V1u2_T));

  {
    Brueckenkran_Template_V1u2_B.PulseGenerator = 0.0;
    Brueckenkran_Template_V1u2_B.Saturation1 = 0.0;
    Brueckenkran_Template_V1u2_B.IO397AnalogInput_o1 = 0.0;
    Brueckenkran_Template_V1u2_B.IO397AnalogInput_o2 = 0.0;
    Brueckenkran_Template_V1u2_B.V2A = 0.0;
    Brueckenkran_Template_V1u2_B.Bias = 0.0;
    Brueckenkran_Template_V1u2_B.Sum1 = 0.0;
    Brueckenkran_Template_V1u2_B.Saturation = 0.0;
    Brueckenkran_Template_V1u2_B.uGainPE = 0.0;
    Brueckenkran_Template_V1u2_B.Sum = 0.0;
    Brueckenkran_Template_V1u2_B.logic2rad = 0.0;
    Brueckenkran_Template_V1u2_B.Clock = 0.0;
    Brueckenkran_Template_V1u2_B.PulseGenerator1 = 0.0;
    Brueckenkran_Template_V1u2_B.Uk1 = 0.0;
    Brueckenkran_Template_V1u2_B.Uk1_e = 0.0;
    Brueckenkran_Template_V1u2_B.Clock_k = 0.0;
    Brueckenkran_Template_V1u2_B.Integrator = 0.0;
    Brueckenkran_Template_V1u2_B.Sum1_e = 0.0;
    Brueckenkran_Template_V1u2_B.Gain1 = 0.0;
    Brueckenkran_Template_V1u2_B.Gain2 = 0.0;
    Brueckenkran_Template_V1u2_B.RecordingOn = 0.0;
  }

  /* states (continuous) */
  {
    (void) std::memset(static_cast<void *>(&Brueckenkran_Template_V1u2_X), 0,
                       sizeof(X_Brueckenkran_Template_V1u2_T));
  }

  /* states (dwork) */
  (void) std::memset(static_cast<void *>(&Brueckenkran_Template_V1u2_DW), 0,
                     sizeof(DW_Brueckenkran_Template_V1u2_T));
  Brueckenkran_Template_V1u2_DW.DelayInput1_DSTATE = 0.0;
  Brueckenkran_Template_V1u2_DW.DelayInput1_DSTATE_m = 0.0;
  Brueckenkran_Template_V1u2_DW.halfPeriod = 0.0;
  Brueckenkran_Template_V1u2_DW.halfPeriodDetermined = 0.0;
  Brueckenkran_Template_V1u2_DW.StartTime = 0.0;
  Brueckenkran_Template_V1u2_DW.RecordingStartet = 0.0;
  Brueckenkran_Template_V1u2_DW.RecordingActivatedSetBack = 0.0;

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo =
      &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.sfcnInfo;
    Brueckenkran_Template_V1u2_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus
      (Brueckenkran_Template_V1u2_M)));
    Brueckenkran_Template_V1u2_M->Sizes.numSampTimes = (2);
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &Brueckenkran_Template_V1u2_M->Sizes.numSampTimes);
    Brueckenkran_Template_V1u2_M->NonInlinedSFcns.taskTimePtrs[0] = (&rtmGetTPtr
      (Brueckenkran_Template_V1u2_M)[0]);
    Brueckenkran_Template_V1u2_M->NonInlinedSFcns.taskTimePtrs[1] = (&rtmGetTPtr
      (Brueckenkran_Template_V1u2_M)[1]);
    rtssSetTPtrPtr(sfcnInfo,
                   Brueckenkran_Template_V1u2_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(Brueckenkran_Template_V1u2_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(Brueckenkran_Template_V1u2_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (Brueckenkran_Template_V1u2_M));
    rtssSetStepSizePtr(sfcnInfo, &Brueckenkran_Template_V1u2_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested
      (Brueckenkran_Template_V1u2_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &Brueckenkran_Template_V1u2_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &Brueckenkran_Template_V1u2_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &Brueckenkran_Template_V1u2_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo,
                         &Brueckenkran_Template_V1u2_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &Brueckenkran_Template_V1u2_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &Brueckenkran_Template_V1u2_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &Brueckenkran_Template_V1u2_M->solverInfoPtr);
  }

  Brueckenkran_Template_V1u2_M->Sizes.numSFcns = (3);

  /* register each child */
  {
    (void) std::memset(static_cast<void *>
                       (&Brueckenkran_Template_V1u2_M->NonInlinedSFcns.childSFunctions
                        [0]), 0,
                       3*sizeof(SimStruct));
    Brueckenkran_Template_V1u2_M->childSfunctions =
      (&Brueckenkran_Template_V1u2_M->NonInlinedSFcns.childSFunctionPtrs[0]);
    Brueckenkran_Template_V1u2_M->childSfunctions[0] =
      (&Brueckenkran_Template_V1u2_M->NonInlinedSFcns.childSFunctions[0]);
    Brueckenkran_Template_V1u2_M->childSfunctions[1] =
      (&Brueckenkran_Template_V1u2_M->NonInlinedSFcns.childSFunctions[1]);
    Brueckenkran_Template_V1u2_M->childSfunctions[2] =
      (&Brueckenkran_Template_V1u2_M->NonInlinedSFcns.childSFunctions[2]);

    /* Level2 S-Function Block: Brueckenkran_Template_V1u2/<Root>/IO397 Analog Input (sg_fpga_IO397_ad) */
    {
      SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod =
        Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset =
        Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap =
        Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &Brueckenkran_Template_V1u2_M->
                         NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Brueckenkran_Template_V1u2_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.methods2
                           [0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.methods3
                           [0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.methods4
                           [0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.statesInfo2
                         [0]);
        ssSetPeriodicStatesInfo(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        ssSetPortInfoForOutputs(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn0.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn0.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &Brueckenkran_Template_V1u2_B.IO397AnalogInput_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &Brueckenkran_Template_V1u2_B.IO397AnalogInput_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "IO397 Analog Input");
      ssSetPath(rts, "Brueckenkran_Template_V1u2/IO397 Analog Input");
      ssSetRTModel(rts,Brueckenkran_Template_V1u2_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 11);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P9_Size);
        ssSetSFcnParam(rts, 9, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P10_Size);
        ssSetSFcnParam(rts, 10, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogInput_P11_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &Brueckenkran_Template_V1u2_DW.IO397AnalogInput_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &Brueckenkran_Template_V1u2_DW.IO397AnalogInput_PWORK[0]);
      }

      /* registration */
      sg_fpga_IO397_ad(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: Brueckenkran_Template_V1u2/<Root>/IO397 Analog Output (sg_fpga_IO397_da) */
    {
      SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod =
        Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset =
        Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap =
        Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &Brueckenkran_Template_V1u2_M->
                         NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Brueckenkran_Template_V1u2_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.methods2
                           [1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.methods3
                           [1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.methods4
                           [1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.statesInfo2
                         [1]);
        ssSetPeriodicStatesInfo(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);
        ssSetPortInfoForInputs(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn1.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn1.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &Brueckenkran_Template_V1u2_B.uGainPE);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidthAsInt(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "IO397 Analog Output");
      ssSetPath(rts, "Brueckenkran_Template_V1u2/IO397 Analog Output");
      ssSetRTModel(rts,Brueckenkran_Template_V1u2_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogOutput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogOutput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogOutput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogOutput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogOutput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogOutput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogOutput_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       Brueckenkran_Template_V1u2_cal->IO397AnalogOutput_P8_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *)
                 &Brueckenkran_Template_V1u2_DW.IO397AnalogOutput_IWORK);
      ssSetPWork(rts, (void **)
                 &Brueckenkran_Template_V1u2_DW.IO397AnalogOutput_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 2);

        /* IWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &Brueckenkran_Template_V1u2_DW.IO397AnalogOutput_IWORK);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1,
                   &Brueckenkran_Template_V1u2_DW.IO397AnalogOutput_PWORK[0]);
      }

      /* registration */
      sg_fpga_IO397_da(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: Brueckenkran_Template_V1u2/<S1>/Enable File Log (slrealtimeenablelogging) */
    {
      SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod =
        Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset =
        Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap =
        Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &Brueckenkran_Template_V1u2_M->
                         NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.inputOutputPortInfo2[2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Brueckenkran_Template_V1u2_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.methods2
                           [2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.methods3
                           [2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.methods4
                           [2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.statesInfo2
                         [2]);
        ssSetPeriodicStatesInfo(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);
        ssSetPortInfoForInputs(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn2.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &Brueckenkran_Template_V1u2_M->NonInlinedSFcns.Sfcn2.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               &Brueckenkran_Template_V1u2_B.DataTypeConversion);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidthAsInt(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Enable File Log");
      ssSetPath(rts, "Brueckenkran_Template_V1u2/DataLogging/Enable File Log");
      ssSetRTModel(rts,Brueckenkran_Template_V1u2_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* registration */
      slrealtimeenablelogging(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }
  }

  {
    /* user code (Start function Header) */
    {
      uint16_t moduleArchitecture;
      int32_t ErrCode;
      uint32_t *bitstream, i;
      uint8_t *fpgacode;
      char *devname;
      sg_fpga_io3xxModuleIdT moduleId;
      FILE *mcs;
      static char mcsFileName[200];
      static char msg[256];
      sg_initModelRun();

      // Determine path to bitstream file
      if (sg_getModelBaseDir(mcsFileName, sizeof(mcsFileName))) {
        sprintf(msg,
                "Could not determine location of the model on the target machine.");
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        return;
      }

      if ((strlen(mcsFileName) + strlen(
            "/fpga/speedgoat_IO397_50k_CI_02717_v1.mcs") + 1) > sizeof
          (mcsFileName)) {
        sprintf(msg,
                "Path to the bitstream (model name + bitstream name) is too long.");
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        return;
      }

      strcat(mcsFileName, "/fpga/speedgoat_IO397_50k_CI_02717_v1.mcs");
      SG_PRINTF(DEBUG, "Bitstream: %s\n", mcsFileName);
      if ((mcs = fopen(mcsFileName, "r")) == NULL) {
        sprintf(msg, "Bitstream file not found at %s.\n", mcsFileName);
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        SG_PRINTF(ERROR,msg);
        return;
      }

      bitstream = (uint32_t *) malloc(2192012*sizeof(uint32_t));
      fpgacode = (uint8_t *) malloc(2192012*sizeof(uint8_t));
      for (i = 0; i<2192012; i++) {
        fscanf(mcs,"%d\n",&bitstream[i]);
        fpgacode[i] = bitstream[i];
      }

      fclose(mcs);

      // Get module IDs (PIC info)
      SG_PRINTF(INFO,"Getting module information.\n");
      ErrCode = (int32_t)sg_fpga_IO3xxGetModuleId(39750, &moduleId);
      if (ErrCode >= 0) {
        devname = moduleId.devname;
        moduleArchitecture = moduleId.moduleArchitecture;
        SG_PRINTF(DEBUG, "boardType: %d\n", 39750);
        SG_PRINTF(DEBUG, "ErrCode: %d\n", ErrCode);
        SG_PRINTF(DEBUG, "******************************************\n");
        SG_PRINTF(DEBUG, "moduleId->devname: %s\n", moduleId.devname);
        SG_PRINTF(DEBUG, "moduleId->vendorid: 0x%x\n", moduleId.vendorid);
        SG_PRINTF(DEBUG, "moduleId->subvendorid: 0x%x\n", moduleId.subvendorid);
        SG_PRINTF(DEBUG, "moduleId->deviceid: 0x%x\n", moduleId.deviceid);
        SG_PRINTF(DEBUG, "moduleId->subdeviceid: 0x%x\n", moduleId.subdeviceid);
        SG_PRINTF(DEBUG, "moduleId.moduleArchitecture: %d\n",
                  moduleId.moduleArchitecture);
      } else {
        sprintf(msg, "Setup block: board type unknown.");
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        SG_PRINTF(ERROR,msg);
        return;
      }

      // Support for different architectures
      SG_PRINTF(INFO,"Running board specific programming file.\n");
      switch (moduleArchitecture)
      {
       case TEWS_TPMC:
        ErrCode = IO30x_programFPGA(devname, (int16_t)-1, (int16_t)-1,
          (int32_t)1, (int32_t)1,
          (int32_t)0, (uint32_t)2192012, bitstream,
          &moduleId);
        break;

       case TEWS_TXMC:
        if (39750 == 324200) {
          ErrCode = IO324_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (int32_t)0, (uint32_t)2192012, fpgacode,
            (uint32_t)1412370449, &moduleId, (uint32_t)86,
            (uint32_t)0);
        } else if (39750 == 336325 || 39750 == 325160) {
          ErrCode = IO324_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (int32_t)0, (uint32_t)2192012, fpgacode,
            (uint32_t)1412370449, &moduleId, (uint32_t)86,
            (uint32_t)0);
        } else                         // IO31x, IO32x
        {
          ErrCode = IO31x_IO32x_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (int32_t)0, (uint32_t)2192012, fpgacode,
            &moduleId, (uint32_t)86);
        }
        break;

       case ACROMAG_PMC:
        ErrCode = IO331_programmFPGA(devname, (int16_t)-1, (int16_t)-1,
          (int32_t)1, (int32_t)1,
          (uint32_t)2192012, bitstream, &moduleId);
        break;

       case ACROMAG_XMC:
        if (39750 == 332) {
          ErrCode = IO332_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (uint32_t)2192012, bitstream, (uint32_t)1412370449,
            &moduleId);
        } else                         // IO333
        {
          ErrCode = IO333_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (uint32_t)2192012, bitstream, (uint32_t)1412370449,
            &moduleId);
        }
        break;

       case TEWS_MPCIE:
        ErrCode = IO39x_programmFPGA(devname, (int16_t)-1, (int16_t)-1,
          (int32_t)1, (int32_t)1,
          (uint32_t)2192012, fpgacode, (uint32_t)86, &moduleId);
        break;

       default:
        sprintf(msg, "Setup block: module architecture incorrect.");
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);

        // Free the bitstream allocation
        SG_PRINTF(ERROR,msg);
        free(bitstream);
        free(fpgacode);
        return;
      }

      // Free the bitstream allocation
      free(bitstream);
      free(fpgacode);

      // Handle any error states
      switch (ErrCode)
      {
       case NO_ERR:
        // Nothing to do.
        break;

       case BOARD_NOT_FOUND:
        sprintf(msg, "Setup block %s: Board could not be found.\n",devname);
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        SG_PRINTF(ERROR,msg);
        return;

       case EEPROM_ERROR:
        sprintf(msg, "Setup block %s: Error updating board EEPROM.\n", devname);
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        SG_PRINTF(ERROR,msg);
        return;

       case REPROG_ERROR:
        sprintf(msg, "Setup block %s: Error writing new bitstream to FPGA.\n",
                devname);
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        SG_PRINTF(ERROR,msg);
        return;

       case FLASH_ERROR:
        sprintf(msg, "Setup block %s: Bitstream flash storage error.\n", devname);
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        SG_PRINTF(ERROR,msg);
        return;

       case BIST_ERROR:
        sprintf(msg, "Setup block %s: Built in self test error.\n", devname);
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        SG_PRINTF(ERROR,msg);
        return;

       case ICAP_RECONF_FAILED:
        sprintf(msg,
                "Setup block %s: ICAP Reconfiguration was not successful.\n",
                devname);
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        SG_PRINTF(ERROR,msg);
        return;

       case BOARD_TYPE_UNKNOWN:
        sprintf(msg, "Setup block %s: The board type selected is unknown.\n",
                devname);
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        SG_PRINTF(ERROR,msg);
        return;

       default:
        sprintf(msg, "Setup block %s: An unknown error occurred.\n",devname);
        rtmSetErrorStatus(Brueckenkran_Template_V1u2_M, msg);
        SG_PRINTF(ERROR,msg);
        return;
      }

      if (1 == 2) {
        IO3xx_21_update(devname, 1, 0, 0, 0);
      } else if (1 == 3) {
        IO3xx_22_update(devname, 1, 0, 0, 0);
      } else if (1 == 4) {
        IO3xx_24_update(devname, 1, 0, 0, 0, 0);
      }
    }

    /* Start for DiscretePulseGenerator: '<Root>/Pulse Generator' */
    Brueckenkran_Template_V1u2_DW.clockTickCounter = 0;

    /* Start for S-Function (sg_fpga_IO397_ad): '<Root>/IO397 Analog Input' */
    /* Level2 S-Function Block: '<Root>/IO397 Analog Input' (sg_fpga_IO397_ad) */
    {
      SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[0];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_fpga_IO397_da): '<Root>/IO397 Analog Output' */
    /* Level2 S-Function Block: '<Root>/IO397 Analog Output' (sg_fpga_IO397_da) */
    {
      SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[1];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (overloadoptions): '<S3>/Overload Options Core' */
    {
      /*------------ S-Function Block: <S3>/Overload Options Core  ------------*/
      Brueckenkran_Template_V1u2_DW.OverloadOptionsCore_DWORK2 = true;
    }

    /* Start for DiscretePulseGenerator: '<Root>/Pulse Generator1' */
    Brueckenkran_Template_V1u2_DW.clockTickCounter_m = 0;

    /* Start for S-Function (slrealtimeenablelogging): '<S1>/Enable File Log' */
    /* Level2 S-Function Block: '<S1>/Enable File Log' (slrealtimeenablelogging) */
    {
      SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[2];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }
  }

  /* InitializeConditions for UnitDelay: '<S6>/Delay Input1' */
  Brueckenkran_Template_V1u2_DW.DelayInput1_DSTATE =
    Brueckenkran_Template_V1u2_cal->DetectIncrease_vinit;

  /* InitializeConditions for UnitDelay: '<S5>/Delay Input1' */
  Brueckenkran_Template_V1u2_DW.DelayInput1_DSTATE_m =
    Brueckenkran_Template_V1u2_cal->DetectDecrease_vinit;

  /* SystemInitialize for Enabled SubSystem: '<Root>/Enabled Subsystem' */
  /* InitializeConditions for Integrator: '<S2>/Integrator' */
  Brueckenkran_Template_V1u2_X.Integrator_CSTATE =
    Brueckenkran_Template_V1u2_cal->Integrator_IC;

  /* SystemInitialize for Gain: '<S2>/Gain1' incorporates:
   *  Outport: '<S2>/Out1'
   */
  Brueckenkran_Template_V1u2_B.Gain1 = Brueckenkran_Template_V1u2_cal->Out1_Y0;

  /* End of SystemInitialize for SubSystem: '<Root>/Enabled Subsystem' */

  /* SystemInitialize for MATLAB Function: '<S1>/Triggered_Recording_TimeSpan' */
  Brueckenkran_Template_V1u2_DW.sfEvent = Brueckenkran_Templat_CALL_EVENT;
  Brueckenkran_Template_V1u2_DW.is_active_c2_Brueckenkran_Templ = 0U;
  Brueckenkran_Template_V1u2_DW.halfPeriod = 0.0;
  Brueckenkran_Template_V1u2_DW.halfPeriod_not_empty = true;
  Brueckenkran_Template_V1u2_DW.halfPeriodDetermined = 0.0;
  Brueckenkran_Template_V1u2_DW.halfPeriodDetermined_not_empty = true;
  Brueckenkran_Template_V1u2_DW.RecordingStartet = 0.0;
  Brueckenkran_Template_V1u2_DW.RecordingStartet_not_empty = true;
  Brueckenkran_Template_V1u2_DW.StartTime = 0.0;
  Brueckenkran_Template_V1u2_DW.StartTime_not_empty = true;
  Brueckenkran_Template_V1u2_DW.RecordingActivatedSetBack = 1.0;
  Brueckenkran_Template_V1u2_DW.RecordingActivatedSetBack_not_e = true;

  /* SystemInitialize for Enabled SubSystem: '<S1>/DataloggingONOFF' */

  /* Start for ToAsyncQueueBlock generated from: '<S11>/ia' */
  Brueckenkran_Template_V1u2_DW.TAQSigLogging_InsertedFor_ia_at.SLRTSigHandles =
    slrtRegisterSignalToLoggingService(reinterpret_cast<uintptr_t>
    (&Brueckenkran_Template_V1u2_B.Bias));

  /* Start for ToAsyncQueueBlock generated from: '<S10>/ua' */
  Brueckenkran_Template_V1u2_DW.TAQSigLogging_InsertedFor_ua_at.SLRTSigHandles =
    slrtRegisterSignalToLoggingService(reinterpret_cast<uintptr_t>
    (&Brueckenkran_Template_V1u2_B.Saturation));

  /* Start for ToAsyncQueueBlock generated from: '<S8>/Ia_soll' */
  Brueckenkran_Template_V1u2_DW.TAQSigLogging_InsertedFor_Ia_so.SLRTSigHandles =
    slrtRegisterSignalToLoggingService(reinterpret_cast<uintptr_t>
    (&Brueckenkran_Template_V1u2_B.Saturation1));

  /* Start for ToAsyncQueueBlock generated from: '<S9>/Theta' */
  Brueckenkran_Template_V1u2_DW.TAQSigLogging_InsertedFor_Theta.SLRTSigHandles =
    slrtRegisterSignalToLoggingService(reinterpret_cast<uintptr_t>
    (&Brueckenkran_Template_V1u2_B.logic2rad));

  /* End of SystemInitialize for SubSystem: '<S1>/DataloggingONOFF' */
}

/* Model terminate function */
void Brueckenkran_Template_V1u2_terminate(void)
{
  /* Terminate for S-Function (sg_fpga_IO397_ad): '<Root>/IO397 Analog Input' */
  /* Level2 S-Function Block: '<Root>/IO397 Analog Input' (sg_fpga_IO397_ad) */
  {
    SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_fpga_IO397_da): '<Root>/IO397 Analog Output' */
  /* Level2 S-Function Block: '<Root>/IO397 Analog Output' (sg_fpga_IO397_da) */
  {
    SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (slrealtimeenablelogging): '<S1>/Enable File Log' */
  /* Level2 S-Function Block: '<S1>/Enable File Log' (slrealtimeenablelogging) */
  {
    SimStruct *rts = Brueckenkran_Template_V1u2_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* user code (Terminate function Trailer) */
  {
    volatile io3xx_pull *ptrIO31x_pull;
    volatile io3xx_2x *ptrio3xx_2x;
    uint16_t moduleArchitecture;
    sg_fpga_io3xxModuleIdT moduleId;

    // Get module IDs (PIC info)
    sg_fpga_IO3xxGetModuleId(39750, &moduleId);
    moduleArchitecture = moduleId.moduleArchitecture;
    SG_PRINTF(DEBUG, "moduleArchitecture %d\n",moduleArchitecture);
    if (moduleArchitecture == TEWS_TXMC) {
      // Get pointer to io31x_pull
      ptrIO31x_pull = (io3xx_pull *)((uintptr_t)io3xxGetAddressSgLib(
        (int32_t)1, SG_FPGA_IO3XX_BAR2) + IO3xx_PULL_BASE);

      // Disable pull resistors
      ptrIO31x_pull->enable = 0x0;     // disable
    }

    // Pull down and disable DIOs
    if ((1 == 2) || (1 == 3)) {
      ptrio3xx_2x = (io3xx_2x *)(
        (uintptr_t)io3xxGetAddressSgLib((int32_t)1, SG_FPGA_IO3XX_BAR2) +
        IO3xx_2x_BASE);
      ptrio3xx_2x->pull = 0xffffffff;  // pull down
      ptrio3xx_2x->dir = 0x0;          // input
      ptrio3xx_2x->update = 0x1;
      sg_wait_s(SG_FPGA_WAIT_TIME_100us);
      ptrio3xx_2x->update = 0x0;
      sg_wait_s(SG_FPGA_WAIT_TIME_1ms);

#if DEBUGGING

      // For debugging output port register of IO-Expander
      sg_wait_s(SG_FPGA_WAIT_TIME_100ms);
      SG_PRINTF(INFO, "last configuration from mdl start\n");
      SG_PRINTF(INFO, "rxData of Expander1: 0x%X\n",
                ptrio3xx_2x->rxDataExpander1);
      SG_PRINTF(INFO, "rxData of Expander2: 0x%X\n",
                ptrio3xx_2x->rxDataExpander2);
      SG_PRINTF(INFO, "rxData of Expander3: 0x%X\n",
                ptrio3xx_2x->rxDataExpander3);
      SG_PRINTF(INFO, "rxData of Expander4: 0x%X\n",
                ptrio3xx_2x->rxDataExpander4);

#endif

    } else if (1 == 4) {
      IO3xx_24_terminate(1);
    }

    freeFPGAModuleSgLib((uint32_t)1);
  }
}
