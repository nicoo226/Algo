#ifndef RTW_HEADER_Brueckenkran_Template_V1u2_cal_h_
#define RTW_HEADER_Brueckenkran_Template_V1u2_cal_h_
#include "rtwtypes.h"

/* Storage class 'PageSwitching', for system '<Root>' */
struct Brueckenkran_Template__cal_type {
  real_T DetectIncrease_vinit;         /* Mask Parameter: DetectIncrease_vinit
                                        * Referenced by: '<S6>/Delay Input1'
                                        */
  real_T DetectDecrease_vinit;         /* Mask Parameter: DetectDecrease_vinit
                                        * Referenced by: '<S5>/Delay Input1'
                                        */
  uint32_T OverloadOptions_maxOverload;
                                  /* Mask Parameter: OverloadOptions_maxOverload
                                   * Referenced by: '<S3>/Overload Options Core'
                                   */
  uint32_T OverloadOptions_startupDur;
                                   /* Mask Parameter: OverloadOptions_startupDur
                                    * Referenced by: '<S3>/Overload Options Core'
                                    */
  real_T Out1_Y0;                      /* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S2>/Out1'
                                        */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<S2>/Integrator'
                                        */
  real_T Gain1_Gain;                   /* Expression: 5
                                        * Referenced by: '<S2>/Gain1'
                                        */
  real_T Gain2_Gain;                   /* Expression: (1.9231/0.0038)*2
                                        * Referenced by: '<S2>/Gain2'
                                        */
  real_T PulseGenerator_Amp;           /* Expression: 0
                                        * Referenced by: '<Root>/Pulse Generator'
                                        */
  real_T PulseGenerator_Period;     /* Computed Parameter: PulseGenerator_Period
                                     * Referenced by: '<Root>/Pulse Generator'
                                     */
  real_T PulseGenerator_Duty;         /* Computed Parameter: PulseGenerator_Duty
                                       * Referenced by: '<Root>/Pulse Generator'
                                       */
  real_T PulseGenerator_PhaseDelay;    /* Expression: 0
                                        * Referenced by: '<Root>/Pulse Generator'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: 0.5
                                        * Referenced by: '<Root>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: -0.5
                                        * Referenced by: '<Root>/Saturation1'
                                        */
  real_T IO397AnalogInput_P1_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P1_Size
                                  * Referenced by: '<Root>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P1;          /* Expression: boardType
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P2_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P2_Size
                                  * Referenced by: '<Root>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P2;          /* Expression: id
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P3_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P3_Size
                                  * Referenced by: '<Root>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P3[2];       /* Expression: chan
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P4_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P4_Size
                                  * Referenced by: '<Root>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P4;          /* Expression: trigger
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P5_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P5_Size
                                  * Referenced by: '<Root>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P5;          /* Expression: range
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P6_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P6_Size
                                  * Referenced by: '<Root>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P6;          /* Expression: ts
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P7_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P7_Size
                                  * Referenced by: '<Root>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P7;          /* Expression: pciSlot
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P8_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P8_Size
                                  * Referenced by: '<Root>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P8;          /* Expression: p.AiTriggerMode
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P9_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P9_Size
                                  * Referenced by: '<Root>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P9;          /* Expression: p.AiClockDivider
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P10_Size[2];
                                /* Computed Parameter: IO397AnalogInput_P10_Size
                                 * Referenced by: '<Root>/IO397 Analog Input'
                                 */
  real_T IO397AnalogInput_P10;         /* Expression: parAiInternalSignal
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P11_Size[2];
                                /* Computed Parameter: IO397AnalogInput_P11_Size
                                 * Referenced by: '<Root>/IO397 Analog Input'
                                 */
  real_T IO397AnalogInput_P11;         /* Expression: parAiDioTriggerChannel
                                        * Referenced by: '<Root>/IO397 Analog Input'
                                        */
  real_T V2A_Gain;                     /* Expression: 2.5
                                        * Referenced by: '<Root>/V2A'
                                        */
  real_T Bias_Bias;                    /* Expression: 0.07
                                        * Referenced by: '<Root>/Bias'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 5
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: -5
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T uGainPE_Gain;                 /* Expression: 1/3
                                        * Referenced by: '<Root>/1//GainPE'
                                        */
  real_T IO397AnalogOutput_P1_Size[2];
                                /* Computed Parameter: IO397AnalogOutput_P1_Size
                                 * Referenced by: '<Root>/IO397 Analog Output'
                                 */
  real_T IO397AnalogOutput_P1;         /* Expression: boardType
                                        * Referenced by: '<Root>/IO397 Analog Output'
                                        */
  real_T IO397AnalogOutput_P2_Size[2];
                                /* Computed Parameter: IO397AnalogOutput_P2_Size
                                 * Referenced by: '<Root>/IO397 Analog Output'
                                 */
  real_T IO397AnalogOutput_P2;         /* Expression: id
                                        * Referenced by: '<Root>/IO397 Analog Output'
                                        */
  real_T IO397AnalogOutput_P3_Size[2];
                                /* Computed Parameter: IO397AnalogOutput_P3_Size
                                 * Referenced by: '<Root>/IO397 Analog Output'
                                 */
  real_T IO397AnalogOutput_P3;         /* Expression: chan
                                        * Referenced by: '<Root>/IO397 Analog Output'
                                        */
  real_T IO397AnalogOutput_P4_Size[2];
                                /* Computed Parameter: IO397AnalogOutput_P4_Size
                                 * Referenced by: '<Root>/IO397 Analog Output'
                                 */
  real_T IO397AnalogOutput_P4;         /* Expression: initVal
                                        * Referenced by: '<Root>/IO397 Analog Output'
                                        */
  real_T IO397AnalogOutput_P5_Size[2];
                                /* Computed Parameter: IO397AnalogOutput_P5_Size
                                 * Referenced by: '<Root>/IO397 Analog Output'
                                 */
  real_T IO397AnalogOutput_P5;         /* Expression: resetVal
                                        * Referenced by: '<Root>/IO397 Analog Output'
                                        */
  real_T IO397AnalogOutput_P6_Size[2];
                                /* Computed Parameter: IO397AnalogOutput_P6_Size
                                 * Referenced by: '<Root>/IO397 Analog Output'
                                 */
  real_T IO397AnalogOutput_P6;         /* Expression: ts
                                        * Referenced by: '<Root>/IO397 Analog Output'
                                        */
  real_T IO397AnalogOutput_P7_Size[2];
                                /* Computed Parameter: IO397AnalogOutput_P7_Size
                                 * Referenced by: '<Root>/IO397 Analog Output'
                                 */
  real_T IO397AnalogOutput_P7;         /* Expression: pciSlot
                                        * Referenced by: '<Root>/IO397 Analog Output'
                                        */
  real_T IO397AnalogOutput_P8_Size[2];
                                /* Computed Parameter: IO397AnalogOutput_P8_Size
                                 * Referenced by: '<Root>/IO397 Analog Output'
                                 */
  real_T IO397AnalogOutput_P8;         /* Expression: span
                                        * Referenced by: '<Root>/IO397 Analog Output'
                                        */
  real_T Offset_Poti_Value;            /* Expression: 2.32
                                        * Referenced by: '<Root>/Offset_Poti'
                                        */
  real_T logic2rad_Gain;               /* Expression: -121.2*(pi/180)/1.75
                                        * Referenced by: '<Root>/logic2rad'
                                        */
  real_T Record_Immediately_Value;     /* Expression: 1
                                        * Referenced by: '<Root>/Record_Immediately'
                                        */
  real_T PulseGenerator1_Amp;          /* Expression: -2
                                        * Referenced by: '<Root>/Pulse Generator1'
                                        */
  real_T PulseGenerator1_Period;   /* Computed Parameter: PulseGenerator1_Period
                                    * Referenced by: '<Root>/Pulse Generator1'
                                    */
  real_T PulseGenerator1_Duty;       /* Computed Parameter: PulseGenerator1_Duty
                                      * Referenced by: '<Root>/Pulse Generator1'
                                      */
  real_T PulseGenerator1_PhaseDelay;   /* Expression: 0
                                        * Referenced by: '<Root>/Pulse Generator1'
                                        */
  real_T Record_Timespan_Activated_Value;/* Expression: 1
                                          * Referenced by: '<Root>/Record_Timespan_Activated'
                                          */
  real_T TimeSpan_Value;               /* Expression: 0.1
                                        * Referenced by: '<Root>/TimeSpan'
                                        */
  real_T Delay_Value;                  /* Expression: 0.05
                                        * Referenced by: '<Root>/Delay'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S1>/Constant1'
                                        */
};

/* Storage class 'PageSwitching' */
extern Brueckenkran_Template__cal_type Brueckenkran_Template__cal_impl;
extern Brueckenkran_Template__cal_type *Brueckenkran_Template_V1u2_cal;

#endif                        /* RTW_HEADER_Brueckenkran_Template_V1u2_cal_h_ */
