#include "Brueckenkran_Template_V1u2_cal.h"
#include "Brueckenkran_Template_V1u2.h"

/* Storage class 'PageSwitching' */
Brueckenkran_Template__cal_type Brueckenkran_Template__cal_impl = {
  /* Mask Parameter: DetectIncrease_vinit
   * Referenced by: '<S6>/Delay Input1'
   */
  0.0,

  /* Mask Parameter: DetectDecrease_vinit
   * Referenced by: '<S5>/Delay Input1'
   */
  0.0,

  /* Mask Parameter: OverloadOptions_maxOverload
   * Referenced by: '<S3>/Overload Options Core'
   */
  10U,

  /* Mask Parameter: OverloadOptions_startupDur
   * Referenced by: '<S3>/Overload Options Core'
   */
  1U,

  /* Computed Parameter: Out1_Y0
   * Referenced by: '<S2>/Out1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Integrator'
   */
  0.0,

  /* Expression: 5
   * Referenced by: '<S2>/Gain1'
   */
  5.0,

  /* Expression: (1.9231/0.0038)*2
   * Referenced by: '<S2>/Gain2'
   */
  1012.1578947368421,

  /* Expression: 0
   * Referenced by: '<Root>/Pulse Generator'
   */
  0.0,

  /* Computed Parameter: PulseGenerator_Period
   * Referenced by: '<Root>/Pulse Generator'
   */
  20000.0,

  /* Computed Parameter: PulseGenerator_Duty
   * Referenced by: '<Root>/Pulse Generator'
   */
  10000.0,

  /* Expression: 0
   * Referenced by: '<Root>/Pulse Generator'
   */
  0.0,

  /* Expression: 0.5
   * Referenced by: '<Root>/Saturation1'
   */
  0.5,

  /* Expression: -0.5
   * Referenced by: '<Root>/Saturation1'
   */
  -0.5,

  /* Computed Parameter: IO397AnalogInput_P1_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 1.0 },

  /* Expression: boardType
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  39750.0,

  /* Computed Parameter: IO397AnalogInput_P2_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 1.0 },

  /* Expression: id
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  1.0,

  /* Computed Parameter: IO397AnalogInput_P3_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 2.0 },

  /* Expression: chan
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 2.0 },

  /* Computed Parameter: IO397AnalogInput_P4_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 1.0 },

  /* Expression: trigger
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  1.0,

  /* Computed Parameter: IO397AnalogInput_P5_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 1.0 },

  /* Expression: range
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  6.0,

  /* Computed Parameter: IO397AnalogInput_P6_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 1.0 },

  /* Expression: ts
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  -1.0,

  /* Computed Parameter: IO397AnalogInput_P7_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 1.0 },

  /* Expression: pciSlot
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  -1.0,

  /* Computed Parameter: IO397AnalogInput_P8_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 1.0 },

  /* Expression: p.AiTriggerMode
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  2.0,

  /* Computed Parameter: IO397AnalogInput_P9_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 1.0 },

  /* Expression: p.AiClockDivider
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  0.0,

  /* Computed Parameter: IO397AnalogInput_P10_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 1.0 },

  /* Expression: parAiInternalSignal
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  1.0,

  /* Computed Parameter: IO397AnalogInput_P11_Size
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  { 1.0, 1.0 },

  /* Expression: parAiDioTriggerChannel
   * Referenced by: '<Root>/IO397 Analog Input'
   */
  1.0,

  /* Expression: 2.5
   * Referenced by: '<Root>/V2A'
   */
  2.5,

  /* Expression: 0.07
   * Referenced by: '<Root>/Bias'
   */
  0.07,

  /* Expression: 0
   * Referenced by: '<Root>/Constant'
   */
  0.0,

  /* Expression: 5
   * Referenced by: '<Root>/Saturation'
   */
  5.0,

  /* Expression: -5
   * Referenced by: '<Root>/Saturation'
   */
  -5.0,

  /* Expression: 1/3
   * Referenced by: '<Root>/1//GainPE'
   */
  0.33333333333333331,

  /* Computed Parameter: IO397AnalogOutput_P1_Size
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  { 1.0, 1.0 },

  /* Expression: boardType
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  39750.0,

  /* Computed Parameter: IO397AnalogOutput_P2_Size
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  { 1.0, 1.0 },

  /* Expression: id
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  1.0,

  /* Computed Parameter: IO397AnalogOutput_P3_Size
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  { 1.0, 1.0 },

  /* Expression: chan
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  1.0,

  /* Computed Parameter: IO397AnalogOutput_P4_Size
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  { 1.0, 1.0 },

  /* Expression: initVal
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  0.0,

  /* Computed Parameter: IO397AnalogOutput_P5_Size
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  { 1.0, 1.0 },

  /* Expression: resetVal
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  1.0,

  /* Computed Parameter: IO397AnalogOutput_P6_Size
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  { 1.0, 1.0 },

  /* Expression: ts
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  -1.0,

  /* Computed Parameter: IO397AnalogOutput_P7_Size
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  { 1.0, 1.0 },

  /* Expression: pciSlot
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  -1.0,

  /* Computed Parameter: IO397AnalogOutput_P8_Size
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  { 1.0, 1.0 },

  /* Expression: span
   * Referenced by: '<Root>/IO397 Analog Output'
   */
  1.0,

  /* Expression: 2.32
   * Referenced by: '<Root>/Offset_Poti'
   */
  2.32,

  /* Expression: -121.2*(pi/180)/1.75
   * Referenced by: '<Root>/logic2rad'
   */
  -1.2087651733812155,

  /* Expression: 1
   * Referenced by: '<Root>/Record_Immediately'
   */
  1.0,

  /* Expression: -2
   * Referenced by: '<Root>/Pulse Generator1'
   */
  -2.0,

  /* Computed Parameter: PulseGenerator1_Period
   * Referenced by: '<Root>/Pulse Generator1'
   */
  20000.0,

  /* Computed Parameter: PulseGenerator1_Duty
   * Referenced by: '<Root>/Pulse Generator1'
   */
  10000.0,

  /* Expression: 0
   * Referenced by: '<Root>/Pulse Generator1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Record_Timespan_Activated'
   */
  1.0,

  /* Expression: 0.1
   * Referenced by: '<Root>/TimeSpan'
   */
  0.1,

  /* Expression: 0.05
   * Referenced by: '<Root>/Delay'
   */
  0.05,

  /* Expression: 1
   * Referenced by: '<S1>/Constant1'
   */
  1.0
};

Brueckenkran_Template__cal_type *Brueckenkran_Template_V1u2_cal =
  &Brueckenkran_Template__cal_impl;
