#pragma once

#include "SceneObject.h"
#include <QVector3D>
#include <vector>

class MarkerPoints : public SceneObject
{
public:
    MarkerPoints(const std::vector<QVector3D>& pts, const QColor& c = Qt::red, float s = 10.0f);

    void draw(const RenderCamera& renderer, const QColor& color, float) const override;
    void affineMap(const QMatrix4x4& matrix) override;
    SceneObjectType getType() const;

private:
    std::vector<QVector3D> points;
    QColor pointColor;
    float pointSize;
};
