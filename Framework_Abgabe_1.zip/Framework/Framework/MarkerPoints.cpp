#include "MarkerPoints.h"


MarkerPoints::MarkerPoints(const std::vector<QVector3D>& pts, const QColor& c, float s)
    : points(pts), pointColor(c), pointSize(s)
{
    type = SceneObjectType::ST_POINT_CLOUD;
}

void MarkerPoints::draw(const RenderCamera& renderer, const QColor&, float) const
{
    for (const auto& p : points)
        renderer.renderPoint(p, pointColor, pointSize); // <-- sollte verfügbar sein
}

void MarkerPoints::affineMap(const QMatrix4x4& matrix)
{
    for (auto& p : points)
        p = matrix.map(p);
}

SceneObjectType MarkerPoints::getType() const
{
    return type;
}
