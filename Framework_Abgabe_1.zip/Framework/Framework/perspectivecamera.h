#pragma once

#include "SceneObject.h"
#include <QMatrix4x4>
#include <QColor>


class PerspectiveCamera: public SceneObject
{
private:
    QVector3D position;         // Projektionszentrum
    QVector3D lookAt;    // Richtung, in die die Kamera schaut
    QVector3D up;
    float focalLength;       // Brennweite
    float fov;
    float aspectRatio;

public:
    void draw(const RenderCamera& renderer, const QColor& color=Qt::red, float lineWidth=1.0f) const override;
    SceneObjectType getType() const ;
    void affineMap(const QMatrix4x4& matrix) override;
    PerspectiveCamera(const QVector3D& position, const QVector3D& lookAt, const QVector3D& up, float fov, float aspectRatio, float focalLength);
};




