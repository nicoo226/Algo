#include "perspectivecamera.h"

void PerspectiveCamera::draw(const RenderCamera& renderer, const QColor& color, float lineWidth) const {
    // 1. Kamerarichtung
    QVector3D z = (lookAt - position).normalized();
    QVector3D x = QVector3D::crossProduct(z, up).normalized();
    QVector3D y = QVector3D::crossProduct(x, z).normalized();

    // 2. Bildfläche zentriert in Sichtachse mit passender Größe
    float imgHeight = 2.0f * focalLength * tan(fov * 0.5f * M_PI / 180.0f);
    float imgWidth = imgHeight * aspectRatio;

    QVector3D imageCenter = position + z * focalLength;
    QVector3D right = QVector3D(x * (imgWidth / 2.0f));
    QVector3D upVec = QVector3D(y * (imgHeight / 2.0f));

    QVector3D topLeft     = imageCenter + upVec - right;
    QVector3D topRight    = imageCenter + upVec + right;
    QVector3D bottomLeft  = imageCenter - upVec - right;
    QVector3D bottomRight = imageCenter - upVec + right;

    // 3. Kameraachsen zeichnen
    renderer.renderLine(position, position + x, Qt::red, lineWidth);
    renderer.renderLine(position, position + y, Qt::green, lineWidth);
    renderer.renderLine(position, position + z, Qt::blue, lineWidth);

    // 4. Bildfläche als Rechteck zeichnen
    renderer.renderLine(topLeft, topRight, color, lineWidth);
    renderer.renderLine(topRight, bottomRight, color, lineWidth);
    renderer.renderLine(bottomRight, bottomLeft, color, lineWidth);
    renderer.renderLine(bottomLeft, topLeft, color, lineWidth);

    // 5. Projektionslinien von Zentrum zu Ecken
    renderer.renderLine(position, topLeft, color, lineWidth);
    renderer.renderLine(position, topRight, color, lineWidth);
    renderer.renderLine(position, bottomLeft, color, lineWidth);
    renderer.renderLine(position, bottomRight, color, lineWidth);
}

SceneObjectType PerspectiveCamera::getType() const {
    return SceneObjectType::ST_PERSPECTIVE_CAMERA;
}

void PerspectiveCamera::affineMap(const QMatrix4x4& matrix) {
    // Wenden Sie die affine Transformation auf die Kamera-Position und Blickrichtung an
    //position = matrix * position;
    //lookAt = matrix * lookAt;

    // Wenn du willst, dass der Up-Vektor auch transformiert wird, kannst du das hier hinzufügen:
    //up = matrix * up;
}

PerspectiveCamera::PerspectiveCamera(const QVector3D& position, const QVector3D& lookAt, const QVector3D& up, float fov, float aspectRatio, float focalLength)
    : position(position), lookAt(lookAt), up(up), fov(fov), aspectRatio(aspectRatio), focalLength(focalLength) {}









